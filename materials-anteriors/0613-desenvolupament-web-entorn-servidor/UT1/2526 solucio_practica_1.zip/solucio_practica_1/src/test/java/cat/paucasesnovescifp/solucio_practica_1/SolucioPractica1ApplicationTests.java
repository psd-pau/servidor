package cat.paucasesnovescifp.solucio_practica_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SolucioPractica1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
