package cat.paucasesnovescifp.solucio_practica_1.service;

import org.springframework.stereotype.Service;

/**
 * Servei encarregat de simular l'exportació dels informes
 * que actualment estan guardats a la cache.
 *
 *     - Simula una tasca "pesada" o lenta (per exemple, exportar fitxers o enviar correus).
 *     - Mostra com un servei pot dependre d'un altre (ReportCache).
 *     - Permet introduir la idea de processos de fons o asíncrons.
 */
@Service
public class ExportEngine {

    private final ReportCache reportCache;

    public ExportEngine(ReportCache reportCache) {
        this.reportCache = reportCache;
    }

    /**
     * Simula l'exportació de tots els informes de la cache.
     * Tarda uns segons per fer veure que és una tasca costosa.
     */
    public String exportAll() {
        var reports = reportCache.getAll();

        if (reports.isEmpty()) {
            return " No hi ha informes per exportar.";
        }

        System.out.println(" Iniciant exportació de " + reports.size() + " informes...");

        reports.forEach((format, content) -> {
            try {
                System.out.println("   ▪ Exportant informe " + format.toUpperCase() + "...");
                Thread.sleep(2000); // simula 2 segons per informe
                System.out.println("    Informe " + format.toUpperCase() + " exportat correctament.");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.err.println("    Error exportant " + format + ": " + e.getMessage());
            }
        });

        return " Exportació completada: " + reports.size() + " informes processats.";
    }
}