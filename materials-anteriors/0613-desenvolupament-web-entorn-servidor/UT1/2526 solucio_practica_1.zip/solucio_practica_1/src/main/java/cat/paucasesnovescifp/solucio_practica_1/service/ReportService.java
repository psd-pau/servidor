package cat.paucasesnovescifp.solucio_practica_1.service;


import cat.paucasesnovescifp.solucio_practica_1.domain.ReportGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.UUID;

/**
 * Servei principal encarregat de la generació d'informes.
 *
 * - Rep les dades i el format a generar (html, pdf, etc.)
 * - Selecciona el generador corresponent dins el Map<String, ReportGenerator>
 * - Aplica el watermark i desa a la cache
 * - Notifica a ReportJobService que s'ha generat un informe
 */
@Service
public class ReportService {

    /**
     * Spring injecta automàticament totes les implementacions de ReportGenerator
     * detectades com a @Component dins un Map.
     *
     * ➜ La clau (String) és el nom del bean registrat.
     * ➜ El valor (ReportGenerator) és la instància corresponent.
     *
     * Exemple:
     *  {
     *    "htmlReportGenerator" -> HtmlReportGenerator,
     *    "pdfReportGenerator"  -> PdfReportGenerator
     *  }
     *
     * Això permet seleccionar dinàmicament quin generador s'utilitza segons
     * el format demanat, sense canviar codi ni fer if/else.
     */
    private final Map<String, ReportGenerator> generators;

    /** Servei encarregat d'afegir el watermark a l'informe */
    private final WatermarkService watermarkService;

    /** Servei que simula l'emmagatzematge temporal dels informes */
    private final ReportCache reportCache;

    /** Servei que gestiona la creació dels jobs i actualitza les estadístiques */
    private final ReportJobService reportJobService;

    @Autowired
    public ReportService(Map<String, ReportGenerator> generators,
                         WatermarkService watermarkService,
                         ReportCache reportCache,
                         ReportJobService reportJobService) {
        this.generators = generators;
        this.watermarkService = watermarkService;
        this.reportCache = reportCache;
        this.reportJobService = reportJobService;
    }

    /**
     * Genera un informe segons el format especificat.
     *
     * @param format ("html", "pdf", ...)
     * @param data informació de l'informe
     * @return contingut de l'informe generat (amb watermark aplicat)
     */
    public String generateReport(String format, String data) {
        // Seleccionam el generador corresponent dins el Map
        ReportGenerator generator = generators.get(format + "ReportGenerator");
        if (generator == null) {
            throw new IllegalArgumentException("Format no suportat: " + format);
        }

        //Generam un nou id per al report.
        // ToDo: Chapu a modificar quan veiem DTOs a unitat 2
        String id = UUID.randomUUID().toString();
        String report = generator.generateReport(id, data); // Generam l'informe base
        if (watermarkService != null) {
            report = watermarkService.apply(report);// Aplicam el watermark al contingut      }

        }

        reportCache.store(format + "_" + id, report); // Desa l'informe a la cache (simulació)
        reportJobService.logReportGenerated(format, id); // Notificam al servei de jobs per registrar la generació

        return report;
    }
}