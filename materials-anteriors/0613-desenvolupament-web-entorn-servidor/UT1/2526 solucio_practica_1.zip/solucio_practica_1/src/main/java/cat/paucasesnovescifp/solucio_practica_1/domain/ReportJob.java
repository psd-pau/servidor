package cat.paucasesnovescifp.solucio_practica_1.domain;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.UUID;

@Component
@Scope("prototype")
public class ReportJob {
    private String format;
    private String id;
    private LocalDateTime timestamp;

    public ReportJob() {
        //El deixam buit. Necessari per a Spring
    }

    public void init(String format, String id) {
        this.format = format;
        this.id = id;
        this.timestamp = LocalDateTime.now();
    }

    public String describe() {
        return String.format("[%s] Informe %s generat: %s",
                timestamp, format.toUpperCase(), id);
    }

    public String getFormat() { return format; }
    public String getTitle() { return id; }
    public LocalDateTime getTimestamp() { return timestamp; }

}
