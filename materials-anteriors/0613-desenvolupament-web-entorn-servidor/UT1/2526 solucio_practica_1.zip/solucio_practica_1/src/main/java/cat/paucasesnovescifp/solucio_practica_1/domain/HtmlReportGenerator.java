package cat.paucasesnovescifp.solucio_practica_1.domain;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class HtmlReportGenerator implements ReportGenerator {


    @Override
    public String generateReport(String id, String data) {
        return id + "###HTML Report>>" + data;
    }

}
