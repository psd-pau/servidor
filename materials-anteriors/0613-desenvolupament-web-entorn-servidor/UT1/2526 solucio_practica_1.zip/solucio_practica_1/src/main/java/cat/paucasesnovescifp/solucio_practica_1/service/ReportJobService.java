package cat.paucasesnovescifp.solucio_practica_1.service;

import cat.paucasesnovescifp.solucio_practica_1.domain.ReportJob;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Servei encarregat de gestionar els jobs de generació d'informes.
 *
 * - Cada vegada que un informe és generat per ReportService,
 *   aquest servei crea un nou ReportJob (bean amb scope "prototype")
 *   i el desa a l'historial.
 *
 * - També actualitza les estadístiques globals mitjançant ReportStatistics.
 */
@Service
public class ReportJobService {

    private final List<ReportJob> history = new ArrayList<>();
    private final ReportStatistics statistics;

    /**
     * ObjectFactory<ReportJob> és una "fàbrica" proporcionada per Spring
     * que ens permet obtenir una nova instància del bean ReportJob cada vegada
     * que ho necessitem.
     *
     * - Per què és necessari?
     * - ReportJob està marcat amb @Scope("prototype"), per tant Spring no el crea
     *   automàticament en arrencar.
     * - Amb ObjectFactory podem demanar a Spring que ens en creï un
     *   de nou quan el necessitem (per exemple, a cada execució d'un informe).
     *
     * - Cada vegada que cridam jobFactory.getObject(),
     *     ➜ Spring crea un nou ReportJob independent.
     */
    private final ObjectFactory<ReportJob> jobFactory;

    @Autowired
    public ReportJobService(ReportStatistics statistics, ObjectFactory<ReportJob> jobFactory) {
        this.statistics = statistics;
        this.jobFactory = jobFactory;
    }

    /**
     * Crea un nou ReportJob, l’inicialitza amb format i títol,
     * l’afegeix a l’historial i actualitza les estadístiques.
     */
    public void logReportGenerated(String format, String id) {
        // Cream una nova instància prototype gestionada per Spring
        //Empram això en lloc de new
        ReportJob job = jobFactory.getObject();

        // Inicialitzam el job amb les dades d’aquesta execució
        job.init(format, id);
        history.add(job); // Desa a historial intern
        statistics.registerJob(job); // Actualitza estadístiques globals
        System.out.println(job.describe()); //Mostra log de proves (ToDo: Eliminar a producció)
    }

    /** Retorna l'historial de tots els jobs generats */
    public List<String> getHistoryDescriptions() {
        return history.stream()
                .map(ReportJob::describe)
                .toList();
    }

    /** Retorna el resum de les estadístiques globals */
    public String getStatisticsSummary() {
        return statistics.summary();
    }
}
