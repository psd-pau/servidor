package cat.paucasesnovescifp.solucio_practica_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SolucioPractica1Application {

    /*
    Flux d'aplicació visual


                             ┌──────────────────────────────────────┐
                             │            CLIENT (HTTP)             │
                             └──────────────────────────────────────┘
                                           │
              ┌────────────────────────────┴────────────────────────────┐
              │                                                         │
              ▼                                                         ▼
 ┌──────────────────────────────┐                           ┌───────────────────────────┐
 │       ReportController       │                           │       ExportController    │
 │  /report/html, /report/pdf   │                           │  /report/export           │
 │  /report/stats               │                           └──────────────┬────────────┘
 └──────────────┬───────────────┘                                          │
                │                                                          ▼
                ▼                                            ┌──────────────────────────┐
       ┌──────────────────────────┐                          │       ExportEngine       │
       │      ReportService       │                          │ (simula exportació       │
       │  Genera, marca, desa i   │                          │  d'informes existents)   │
       │  registra informes       │                          │  @Service singleton      │
       └───────────┬──────────────┘                          └────────┬─────────────────┘
                   │                                                  │
                   │                                                  │
                   │                                                  │
   ┌───────────────┼──────────────────────────────────────────┐       │
   │               │                  │                       │       │
   ▼               ▼                  ▼                       ▼       ▼
┌───────────┐  ┌────────────────┐  ┌────────────────────┐   ┌──────────────────────────┐
│Generators │  │WatermarkService│  │ReportJobService    │   │        ReportCache       │
│(HTML/PDF) │  │(afegeix marca) │  │(gestiona execucions│   │ (desa i proveeix         │
│@Component │  │@Service        │  │ i estadístiques)   │   │  informes generats)      │
│singleton  │  │singleton       │  │@Service singleton  │   │ @Service singleton       │
└───────────┘  └────────────────┘  └─────────┬──────────┘   │@PostConstruct/@PreDestroy│
                                             │              └──────────────────────────┘
                                      ┌───────────────────┐
                                      │                   │
                                      ▼                   ▼
                    ┌───────────────────────────┐   ┌──────────────────────────┐
                    │        ReportJob          │   │     ReportStatistics     │
                    │  @Component prototype     │   │ (acumula mètriques)      │
                    └───────────────────────────┘   │ @Service singleton       │
                                                    └──────────────────────────┘

     */

	public static void main(String[] args) {
		SpringApplication.run(SolucioPractica1Application.class, args);
	}

}
