package cat.paucasesnovescifp.solucio_practica_1.controller;

import cat.paucasesnovescifp.solucio_practica_1.service.ExportEngine;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controlador dedicat exclusivament a la funcionalitat d'exportació.
 *
 *  - Motiu:
 *     - En lloc d'afegir aquest endpoint dins ReportController,
 *       el separam per mostrar que a una aplicació Spring Boot
 *       hi pot haver múltiples controladors REST, cadascun amb
 *       responsabilitats clares i independents.
 *
 * - Aquest controlador accedeix al servei ExportEngine,
 *     que simula una exportació de tots els informes
 *     actualment desats a la cache.
 *
 * ➜ En una aplicació real, aquesta acció podria correspondre
 *     a l'enviament per correu, desament a disc o transferència a un servidor.
 */
@RestController
@RequestMapping("/report/export")
public class ExportController {

    private final ExportEngine exportEngine;

    public ExportController(ExportEngine exportEngine) {
        this.exportEngine = exportEngine;
    }

    /**
     * Endpoint per simular l'exportació de tots els informes.
     * Tarda uns segons per cada informe per fer veure
     * que és un procés costós.
     *
     * Exemple d'ús:
     *   GET /report/export
     */
    @GetMapping
    public String exportAllReports() {
        return exportEngine.exportAll();
    }
}
