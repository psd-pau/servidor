package cat.paucasesnovescifp.solucio_practica_1.controller;


import cat.paucasesnovescifp.solucio_practica_1.service.ReportJobService;
import cat.paucasesnovescifp.solucio_practica_1.service.ReportService;
import cat.paucasesnovescifp.solucio_practica_1.service.ReportServiceHtml;
import cat.paucasesnovescifp.solucio_practica_1.service.ReportServicePdf;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("/report")
public class ReportController {

    private ReportServiceHtml reportServiceHtml;
    private ReportServicePdf reportServicePdf;
    private ReportService reportService;
    private ReportJobService reportJobService;

    @Autowired
    public ReportController(
            ReportServiceHtml reportServiceHtml,
            ReportServicePdf  reportServicePdf,
            ReportService reportService,
            ReportJobService reportJobService) {
        this.reportServiceHtml = reportServiceHtml;
        this.reportServicePdf = reportServicePdf;
        this.reportService = reportService;
        this.reportJobService = reportJobService;

    }

    @GetMapping("/html")
    public String generateHtmlReport() {
        //return reportServiceHtml.generateReport();
        return reportService.generateReport("html", "Dades de prova");
    }

    @GetMapping("/pdf")
    public String generatePdfReport() {
        //return reportServicePdf.generateReport();
        return reportService.generateReport("pdf", "Dades de prova");
    }

    @GetMapping("/stats")
    public String getStatistics() {
        return reportJobService.getStatisticsSummary();
    }

}
