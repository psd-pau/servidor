package cat.paucasesnovescifp.solucio_practica_1.domain;



public interface ReportGenerator {

    public String generateReport(String id, String data);

}
